// Fungsi server Vercel: mengambil Google Sheet sebagai file Excel (xlsx) lalu meneruskannya ke halaman.
// Berjalan di server, jadi tidak terkena batasan CORS browser.
// Syarat: berbagi file Google Sheet diatur "Siapa saja yang memiliki link" (bisa melihat).
// ID file bisa diganti lewat Environment Variable SHEET_ID di pengaturan proyek Vercel.
const DEFAULT_ID = '1r0swpSbld_Uukv-urpt8ch-Y0g0l2uCu0djwlp1a4wI';

module.exports = async function handler(req, res) {
  const id = process.env.SHEET_ID || DEFAULT_ID;
  const url = `https://docs.google.com/spreadsheets/d/${encodeURIComponent(id)}/export?format=xlsx`;
  try {
    const r = await fetch(url, { redirect: 'follow' });
    if (!r.ok) {
      res.status(r.status === 404 ? 404 : 502).setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.send(`Google membalas kode ${r.status}. Pastikan file dibagikan sebagai "Siapa saja yang memiliki link".`);
      return;
    }
    const buf = Buffer.from(await r.arrayBuffer());
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    // simpan 30 detik di CDN Vercel supaya Google tidak dipanggil berulang oleh banyak pengunjung
    res.setHeader('Cache-Control', 'public, s-maxage=30, stale-while-revalidate=60');
    res.status(200).send(buf);
  } catch (e) {
    res.status(502).setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.send('Gagal mengambil Google Sheet: ' + (e && e.message ? e.message : e));
  }
};
