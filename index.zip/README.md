# Dashboard Gabungan - PT Perintis Perkasa

Isi: index.html (3 tab: Piutang Unit, Piutang GR & BP, Belum Buka Faktur), api/sheet.js, package.json.
Deploy ke Vercel dengan index.html dan api/sheet.js di folder yang sama.
Tab "Belum Buka Faktur" membaca Google Sheet lewat /api/sheet (ID bisa diganti lewat Environment Variable SHEET_ID).
Google Sheet harus dibagikan sebagai "Siapa saja yang memiliki link" (Viewer).
