# Perintis Group - Dashboard Gabungan

Isi: index.html (4 tab: Piutang Unit, BPKB Cash, Piutang GR & BP, Belum Buka Faktur), api/sheet.js, package.json.
Deploy ke Vercel dengan index.html dan api/sheet.js di folder yang sama.
Google Sheet harus dibagikan sebagai "Siapa saja yang memiliki link" (Viewer).
